Aden Chess Database - Android project (WebView, fullscreen, no browser bar)

Option 1 - Android Studio:
  1. File > Open > select this folder, wait for Gradle sync.
  2. Build > Build Bundle(s) / APK(s) > Build APK(s).
  3. APK: app/build/outputs/apk/debug/app-debug.apk

Option 2 - GitHub (no Android Studio):
  1. Create a repository and upload ALL files of this folder (including .github).
  2. Open the Actions tab > Build APK > wait for green check.
  3. Download "Aden-Chess-APK" from the run page, unzip, install the APK.
